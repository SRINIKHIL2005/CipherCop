# 🛡️ CipherCop Quick Start Guide

## 🚀 How to Run

### Method 1: Quick Start (Recommended)
1. Navigate to `backend` folder
2. Double-click `start_ciphercop.bat`
3. Open `frontend/index.html` in your browser

### Method 2: Manual Start
1. Open terminal in `backend` folder
2. Run: `python app.py`
3. Open `frontend/index.html` in browser

## 🎯 Testing the System

### Website Analysis Test
- URL: `https://suspicious-phishing-site.com`
- URL: `https://fake-bank-login.net`
- URL: `https://malicious-download.org`

### Mobile App Analysis Test
- App Name: `Fake WhatsApp`
- Package: `com.suspicious.whatsapp`
- Description: `Free messaging with suspicious permissions`

## 🔧 API Status

### Current Mode: DEMO MODE ✅
- ✅ Fallback AI analysis working
- ✅ Detailed fraud detection responses
- ✅ All UI features functional
- ⚠️ Google Gemini API needs activation for full AI mode

### To Enable Full AI Mode:
1. Visit: https://console.developers.google.com/apis/api/generativelanguage.googleapis.com/overview?project=1034250232006
2. Click "Enable"
3. Wait 2-3 minutes
4. Restart the backend server

## 🎨 UI Features Working

✅ Video background with transparency
✅ Glassmorphism effects and blur
✅ Floating particle animations  
✅ Gradient text and hover effects
✅ Responsive mobile design
✅ Loading spinners and transitions
✅ Professional dark theme

## 📊 Expected Behavior

1. **Start Backend** → Server runs on localhost:5000
2. **Open Frontend** → Beautiful glassmorphism interface loads
3. **Enter URL/App** → Click analyze button
4. **AI Analysis** → Detailed fraud detection results appear
5. **Demo Mode** → Realistic simulated responses (until API enabled)

Your advanced AI fraud detection system is ready! 🎉
