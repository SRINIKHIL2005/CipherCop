from flask import Flask, request, jsonify
from flask_cors import CORS
import json

app = Flask(__name__)
CORS(app, resources={
    r"/api/*": {"origins": "*"},
    r"/*": {"origins": "*"}
})

@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    return response

@app.route('/')
def home():
    return jsonify({"message": "CipherCop Backend - Working!", "status": "active"})

@app.route('/classify/content', methods=['POST', 'OPTIONS'])
def classify_content():
    if request.method == 'OPTIONS':
        return '', 200
    
    try:
        data = request.get_json(force=True)
        if not data or 'content' not in data:
            return jsonify({"error": "Content is required", "success": False}), 400
        
        content = data.get('content', '').lower()
        
        # Simple but effective classification
        risk_score = 0
        patterns = []
        
        # Fraudulent keywords (high risk)
        fraudulent_keywords = [
            'urgent', 'verify', 'suspended', 'click here', 'account locked',
            'expires', 'immediate', 'winner', 'congratulations', 'claim',
            'credit card', 'social security', 'bank account', 'password'
        ]
        
        for keyword in fraudulent_keywords:
            if keyword in content:
                risk_score += 20
                patterns.append(f"High-risk keyword: {keyword}")
        
        # Suspicious patterns (medium risk)
        suspicious_keywords = ['offer', 'limited time', 'act now', 'free', 'guaranteed']
        for keyword in suspicious_keywords:
            if keyword in content:
                risk_score += 10
                patterns.append(f"Suspicious keyword: {keyword}")
        
        # Determine classification
        if risk_score >= 60:
            classification = "Fraudulent"
            confidence = 90
            recommendation = "HIGH RISK: Do not respond or click any links. Report as fraud."
        elif risk_score >= 30:
            classification = "Suspicious"
            confidence = 75
            recommendation = "CAUTION: Verify sender and avoid sharing personal information."
        else:
            classification = "Legitimate"
            confidence = 85
            recommendation = "Content appears safe. Continue with normal caution."
        
        return jsonify({
            "success": True,
            "classification": classification,
            "risk_score": min(risk_score, 100),
            "confidence": confidence,
            "patterns_detected": patterns[:5],
            "recommendation": recommendation,
            "timestamp": "2025-08-30T13:25:00"
        })
        
    except Exception as e:
        return jsonify({"error": str(e), "success": False}), 500

@app.route('/analyze/url', methods=['POST', 'OPTIONS'])
def analyze_url():
    if request.method == 'OPTIONS':
        return '', 200
    
    try:
        data = request.get_json(force=True)
        url = data.get('url', '')
        
        # Simple URL analysis
        safe = True
        risk_level = "Low"
        issues = []
        
        if any(suspicious in url.lower() for suspicious in ['bit.ly', 'tinyurl', 'suspicious']):
            safe = False
            risk_level = "High"
            issues.append("URL shortener or suspicious domain detected")
        
        return jsonify({
            "success": True,
            "url": url,
            "safe": safe,
            "risk_level": risk_level,
            "issues": issues,
            "content_classification": "Legitimate",
            "overall_risk_score": 0 if safe else 75,
            "recommendation": "ALLOW" if safe else "BLOCK"
        })
    except Exception as e:
        return jsonify({"error": str(e), "success": False}), 500

@app.route('/analyze/message', methods=['POST', 'OPTIONS'])
def analyze_message():
    if request.method == 'OPTIONS':
        return '', 200
    
    try:
        data = request.get_json(force=True)
        sender = data.get('sender', '')
        subject = data.get('subject', '')
        body = data.get('body', '')
        
        combined = f"{sender} {subject} {body}".lower()
        
        # Quick message analysis
        risk_score = 0
        if 'urgent' in combined: risk_score += 30
        if 'verify' in combined: risk_score += 25
        if 'click' in combined: risk_score += 20
        
        classification = "Fraudulent" if risk_score >= 50 else "Suspicious" if risk_score >= 25 else "Legitimate"
        
        return jsonify({
            "success": True,
            "message_type": "email" if '@' in sender else "text",
            "classification": classification,
            "risk_score": risk_score,
            "confidence": 80,
            "patterns_detected": ["Message analysis complete"],
            "email_risk_factors": [],
            "action_required": classification != "Legitimate"
        })
    except Exception as e:
        return jsonify({"error": str(e), "success": False}), 500

@app.route('/threat/report', methods=['GET', 'OPTIONS'])
def threat_report():
    if request.method == 'OPTIONS':
        return '', 200
    
    try:
        threats = [
            {
                "type": "Phishing Campaign",
                "target": "Banking customers",
                "severity": "High",
                "description": "Fake bank login pages targeting major banks"
            },
            {
                "type": "Romance Scam",
                "target": "Dating app users",
                "severity": "Medium", 
                "description": "Fraudsters creating fake profiles to request money"
            }
        ]
        
        return jsonify({
            "success": True,
            "report_date": "2025-08-30T13:25:00",
            "current_threats": threats,
            "threat_level": "ELEVATED",
            "recommendations": [
                "Verify sender identity before responding",
                "Never provide personal information via email",
                "Use official website URLs instead of clicking links"
            ]
        })
    except Exception as e:
        return jsonify({"error": str(e), "success": False}), 500

if __name__ == '__main__':
    print("🛡️ CipherCop Backend Starting...")
    print("✅ Content Classification: ACTIVE")
    print("✅ URL Analysis: READY")
    print("✅ Message Analysis: READY") 
    print("✅ Threat Intelligence: READY")
    print("🌐 Server running on http://localhost:5001")
    
    app.run(debug=True, host='localhost', port=5001, use_reloader=False)
