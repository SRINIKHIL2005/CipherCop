import requests
import json

# Test the API endpoints
base_url = "http://localhost:5000"

print("Testing AI Fraudulent Content Detector API...")
print("=" * 50)

# Test 1: Check if server is running
try:
    response = requests.get(f"{base_url}/")
    print(f"✅ Server Status: {response.json()}")
except Exception as e:
    print(f"❌ Server Error: {e}")
    exit(1)

# Test 2: Test website analysis
print("\n🌐 Testing Website Analysis:")
try:
    test_data = {"url": "https://phishing-example.com"}
    response = requests.post(f"{base_url}/analyze/website", 
                           headers={"Content-Type": "application/json"},
                           json=test_data)
    result = response.json()
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(result, indent=2)}")
except Exception as e:
    print(f"❌ Website Analysis Error: {e}")

# Test 3: Test app analysis
print("\n📱 Testing App Analysis:")
try:
    test_data = {
        "app_name": "Fake WhatsApp", 
        "package": "com.fake.whatsapp", 
        "description": "Free messaging app with suspicious permissions"
    }
    response = requests.post(f"{base_url}/analyze/app", 
                           headers={"Content-Type": "application/json"},
                           json=test_data)
    result = response.json()
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(result, indent=2)}")
except Exception as e:
    print(f"❌ App Analysis Error: {e}")

print("\n" + "=" * 50)
print("API Testing Complete!")
