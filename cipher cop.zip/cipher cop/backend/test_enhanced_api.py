#!/usr/bin/env python3
"""
Test script for enhanced CipherCop API with automatic classification
"""

import requests
import json

API_BASE = "http://localhost:5000"

def test_enhanced_website_analysis():
    """Test enhanced website analysis with automatic classification"""
    print("🌐 Testing Enhanced Website Analysis...")
    
    test_urls = [
        "https://phishing-example.com/verify-account",
        "https://google.com",
        "https://bit.ly/suspicious-link",
        "https://fake-bank-login.net/urgent-action"
    ]
    
    for url in test_urls:
        print(f"\n📡 Analyzing: {url}")
        
        response = requests.post(f"{API_BASE}/analyze/website", 
                               json={"url": url})
        
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Status: {result.get('status')}")
            
            # Print automatic classification
            if 'automatic_classification' in result:
                classification = result['automatic_classification']
                print(f"🔍 Classification: {classification['category']}")
                print(f"📊 Risk Score: {classification['risk_score']}/100")
                print(f"🎯 Confidence: {classification['confidence']:.1%}")
                print(f"⚠️ Threats: {len(classification['threat_indicators'])}")
            
            # Print proactive threats
            if 'proactive_threats' in result:
                threats = result['proactive_threats']
                print(f"🛡️ Proactive Threats: {len(threats)}")
                for threat in threats:
                    print(f"   • {threat['type']}: {threat['severity']}")
        else:
            print(f"❌ Error: {response.status_code}")

def test_content_classification():
    """Test direct content classification endpoint"""
    print("\n\n🔍 Testing Content Classification...")
    
    test_contents = [
        {
            "content": "URGENT! Your account has been suspended. Click here immediately to verify your password and social security number.",
            "description": "Phishing attempt"
        },
        {
            "content": "Welcome to our newsletter! Here are this week's tech updates and industry news.",
            "description": "Legitimate content"
        },
        {
            "content": "GUARANTEED 500% return on investment! Bitcoin doubler - send us crypto and get 5x back!",
            "description": "Financial fraud"
        }
    ]
    
    for test in test_contents:
        print(f"\n📝 Testing: {test['description']}")
        
        response = requests.post(f"{API_BASE}/classify/content",
                               json={"content": test["content"]})
        
        if response.status_code == 200:
            result = response.json()
            classification = result['classification']
            threats = result['proactive_threats']
            
            print(f"🔍 Classification: {classification['category']}")
            print(f"📊 Risk Score: {classification['risk_score']}/100")
            print(f"⚠️ Threat Indicators: {len(classification['threat_indicators'])}")
            print(f"🛡️ Proactive Threats: {len(threats)}")
            print(f"💡 Recommendation: {classification['recommendation']}")
        else:
            print(f"❌ Error: {response.status_code}")

def test_threat_intelligence():
    """Test threat intelligence endpoint"""
    print("\n\n🛡️ Testing Threat Intelligence...")
    
    response = requests.get(f"{API_BASE}/threats/intelligence")
    
    if response.status_code == 200:
        result = response.json()
        intel = result['threat_intelligence']
        
        print(f"📊 Total Threat Indicators: {intel['total_indicators']}")
        print(f"🎣 Phishing Keywords: {intel['phishing_keywords']}")
        print(f"💰 Fraud Indicators: {intel['fraud_indicators']}")
        print(f"🌐 Suspicious Domains: {intel['suspicious_domains']}")
        print(f"🔍 Malicious Patterns: {intel['malicious_patterns']}")
        print(f"🕒 Last Updated: {intel['last_updated']}")
    else:
        print(f"❌ Error: {response.status_code}")

def test_mobile_app_analysis():
    """Test enhanced mobile app analysis"""
    print("\n\n📱 Testing Enhanced Mobile App Analysis...")
    
    test_apps = [
        {
            "app_name": "Fake WhatsApp Pro",
            "package": "com.suspicious.whatsapp.fake",
            "description": "Free premium features! Download APK file directly for unlimited messaging and calling."
        },
        {
            "app_name": "Google Chrome",
            "package": "com.android.chrome",
            "description": "Fast, secure web browser by Google"
        }
    ]
    
    for app in test_apps:
        print(f"\n📱 Analyzing: {app['app_name']}")
        
        response = requests.post(f"{API_BASE}/analyze/app", json=app)
        
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Status: {result.get('status')}")
            
            if 'automatic_classification' in result:
                classification = result['automatic_classification']
                print(f"🔍 Classification: {classification['category']}")
                print(f"📊 Risk Score: {classification['risk_score']}/100")
        else:
            print(f"❌ Error: {response.status_code}")

if __name__ == "__main__":
    print("🚀 Testing Enhanced CipherCop API")
    print("=" * 50)
    
    try:
        # Test basic connectivity
        response = requests.get(f"{API_BASE}/")
        if response.status_code == 200:
            print("✅ API Server is running")
            
            # Run all tests
            test_enhanced_website_analysis()
            test_content_classification()
            test_threat_intelligence()
            test_mobile_app_analysis()
            
            print("\n" + "=" * 50)
            print("🎉 All tests completed!")
            
        else:
            print("❌ API Server not responding")
            
    except requests.exceptions.ConnectionError:
        print("❌ Cannot connect to API server. Make sure it's running on localhost:5000")
    except Exception as e:
        print(f"❌ Test error: {str(e)}")
