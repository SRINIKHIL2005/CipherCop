from flask import Flask, request, jsonify
from flask_cors import CORS
import requests
import os
import json
import re
import urllib.parse
from datetime import datetime, timedelta
import hashlib

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

GOOGLE_API_KEY = "AIzaSyB7QtV1FjWXT1sp3Gp0mOsbRbg-oahn14Y"
GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=" + GOOGLE_API_KEY

# Simplified and Working Classification System
class ThreatClassifier:
    def __init__(self):
        # Fraud detection patterns
        self.fraudulent_keywords = [
            'urgent action required', 'verify account immediately', 'suspended account',
            'click here now', 'limited time offer', 'congratulations winner',
            'free money', 'nigerian prince', 'inheritance million', 'bitcoin guaranteed',
            'credit card details', 'social security number', 'bank account number',
            'password expires', 'account locked', 'verify identity'
        ]
        
        # Suspicious patterns
        self.suspicious_keywords = [
            'act now', 'offer expires', 'limited time', 'exclusive deal',
            'no credit check', 'guaranteed income', 'work from home',
            'lose weight fast', 'miracle cure', 'risk free'
        ]
        
        # Legitimate indicators
        self.legitimate_indicators = [
            'privacy policy', 'terms of service', 'contact us', 'customer support',
            'unsubscribe', 'legitimate business', 'established company'
        ]
    
    def classify_content(self, content):
        """Classify content into Legitimate, Suspicious, or Fraudulent"""
        if not content:
            return {"classification": "Legitimate", "risk_score": 0, "confidence": 0}
        
        content_lower = content.lower()
        risk_score = 0
        detected_patterns = []
        
        # Check for fraudulent patterns (high risk)
        for keyword in self.fraudulent_keywords:
            if keyword in content_lower:
                risk_score += 35
                detected_patterns.append(f"Fraudulent pattern: {keyword}")
        
        # Check for suspicious patterns (medium risk)
        for keyword in self.suspicious_keywords:
            if keyword in content_lower:
                risk_score += 15
                detected_patterns.append(f"Suspicious pattern: {keyword}")
        
        # Check for legitimate indicators (reduces risk)
        for indicator in self.legitimate_indicators:
            if indicator in content_lower:
                risk_score -= 10
                detected_patterns.append(f"Legitimate indicator: {indicator}")
        
        # Ensure score stays within bounds
        risk_score = max(0, min(100, risk_score))
        
        # Determine classification
        if risk_score >= 70:
            classification = "Fraudulent"
            confidence = min(95, 70 + (risk_score - 70) * 0.8)
        elif risk_score >= 30:
            classification = "Suspicious"
            confidence = min(85, 60 + (risk_score - 30) * 0.6)
        else:
            classification = "Legitimate"
            confidence = max(70, 90 - risk_score)
        
        return {
            "classification": classification,
            "risk_score": risk_score,
            "confidence": round(confidence, 1),
            "patterns_detected": detected_patterns[:5]  # Limit to top 5
        }
    
    def analyze_url(self, url):
        """Analyze URL for suspicious patterns"""
        if not url:
            return {"safe": True, "risk_level": "Low", "issues": []}
        
        issues = []
        risk_score = 0
        
        # Check for suspicious URL patterns
        suspicious_patterns = [
            (r'[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}', "IP address instead of domain"),
            (r'(paypal|amazon|google|microsoft)\w*\d+', "Brand impersonation with numbers"),
            (r'[a-z]{30,}', "Unusually long domain name"),
            (r'\.(tk|ml|ga|cf|xyz)$', "Suspicious free domain"),
            (r'[a-z]+-[a-z]+-[a-z]+\.(tk|ml|ga|cf)', "Multi-hyphen suspicious domain")
        ]
        
        for pattern, description in suspicious_patterns:
            if re.search(pattern, url.lower()):
                risk_score += 25
                issues.append(description)
        
        # Determine safety
        if risk_score >= 50:
            return {"safe": False, "risk_level": "High", "issues": issues}
        elif risk_score >= 25:
            return {"safe": False, "risk_level": "Medium", "issues": issues}
        else:
            return {"safe": True, "risk_level": "Low", "issues": issues}

# Initialize classifier
threat_classifier = ThreatClassifier()

@app.route('/')
def home():
    return jsonify({"message": "CipherCop Backend - Fraud Detection API", "status": "active"})

# 1. Content Classification Endpoint
@app.route('/classify/content', methods=['POST'])
def classify_content():
    try:
        data = request.get_json()
        if not data or 'content' not in data:
            return jsonify({"error": "Content is required"}), 400
        
        content = data.get('content', '')
        result = threat_classifier.classify_content(content)
        
        return jsonify({
            "success": True,
            "classification": result["classification"],
            "risk_score": result["risk_score"],
            "confidence": result["confidence"],
            "patterns_detected": result["patterns_detected"],
            "timestamp": datetime.now().isoformat(),
            "recommendation": get_recommendation(result["classification"])
        })
    except Exception as e:
        return jsonify({"error": str(e), "success": False}), 500

# 2. URL Safety Checker
@app.route('/analyze/url', methods=['POST'])
def analyze_url():
    try:
        data = request.get_json()
        if not data or 'url' not in data:
            return jsonify({"error": "URL is required"}), 400
        
        url = data.get('url', '')
        result = threat_classifier.analyze_url(url)
        
        # Also classify URL content
        content_result = threat_classifier.classify_content(url)
        
        return jsonify({
            "success": True,
            "url": url,
            "safe": result["safe"],
            "risk_level": result["risk_level"],
            "issues": result["issues"],
            "content_classification": content_result["classification"],
            "overall_risk_score": max(content_result["risk_score"], 
                                    25 if result["risk_level"] == "Medium" else 
                                    50 if result["risk_level"] == "High" else 0),
            "timestamp": datetime.now().isoformat(),
            "recommendation": "BLOCK" if not result["safe"] else "ALLOW"
        })
    except Exception as e:
        return jsonify({"error": str(e), "success": False}), 500

# 3. Email/Message Analysis
@app.route('/analyze/message', methods=['POST'])
def analyze_message():
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "Message data is required"}), 400
        
        # Extract all text content
        subject = data.get('subject', '')
        body = data.get('body', '')
        sender = data.get('sender', '')
        
        combined_content = f"{subject} {body} {sender}"
        
        # Classify the message
        result = threat_classifier.classify_content(combined_content)
        
        # Additional email-specific checks
        email_risk_factors = []
        if '@' not in sender:
            email_risk_factors.append("Invalid sender format")
        if len(subject) > 100:
            email_risk_factors.append("Unusually long subject line")
        if body.count('!') > 5:
            email_risk_factors.append("Excessive exclamation marks")
        
        return jsonify({
            "success": True,
            "message_type": "email" if '@' in sender else "text",
            "classification": result["classification"],
            "risk_score": result["risk_score"],
            "confidence": result["confidence"],
            "patterns_detected": result["patterns_detected"],
            "email_risk_factors": email_risk_factors,
            "timestamp": datetime.now().isoformat(),
            "action_required": result["classification"] != "Legitimate"
        })
    except Exception as e:
        return jsonify({"error": str(e), "success": False}), 500

# 4. Threat Intelligence Report
@app.route('/threat/report', methods=['GET'])
def threat_report():
    try:
        # Simulated threat intelligence data
        current_threats = [
            {
                "type": "Phishing Campaign",
                "target": "Banking customers",
                "severity": "High",
                "description": "Fake bank login pages targeting major banks",
                "indicators": ["suspicious domains with bank names", "urgent account verification messages"]
            },
            {
                "type": "Romance Scam",
                "target": "Dating app users", 
                "severity": "Medium",
                "description": "Fraudsters creating fake profiles to request money",
                "indicators": ["requests for money", "claims of emergency situations"]
            },
            {
                "type": "Cryptocurrency Fraud",
                "target": "Investors",
                "severity": "High", 
                "description": "Fake investment opportunities promising guaranteed returns",
                "indicators": ["guaranteed profits", "bitcoin investment schemes"]
            }
        ]
        
        return jsonify({
            "success": True,
            "report_date": datetime.now().isoformat(),
            "current_threats": current_threats,
            "threat_level": "ELEVATED",
            "recommendations": [
                "Verify sender identity before responding to urgent requests",
                "Never provide personal information via email or text",
                "Use official website URLs instead of clicking links",
                "Report suspicious messages to authorities"
            ]
        })
    except Exception as e:
        return jsonify({"error": str(e), "success": False}), 500

def get_recommendation(classification):
    """Get safety recommendation based on classification"""
    recommendations = {
        "Legitimate": "Content appears safe. Continue with normal caution.",
        "Suspicious": "Exercise caution. Verify sender and avoid sharing personal information.",
        "Fraudulent": "HIGH RISK: Do not respond or click any links. Report as fraud."
    }
    return recommendations.get(classification, "Unknown classification")

if __name__ == '__main__':
    print("🛡️ CipherCop Backend Starting...")
    print("✅ Threat Classification System: ACTIVE")
    print("✅ Proactive Threat Detection: ENABLED") 
    print("✅ Content Analysis: READY")
    print("✅ URL Safety Checker: READY")
    app.run(debug=True, host='127.0.0.1', port=5000)
