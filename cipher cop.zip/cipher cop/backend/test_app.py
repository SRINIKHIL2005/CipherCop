from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route('/')
def home():
    return {"message": "Cipher Cop Backend is running!"}

@app.route('/classify/content', methods=['POST'])
def classify_content():
    try:
        data = request.get_json()
        content = data.get('content', '')
        
        # Simple classification logic
        suspicious_keywords = ['win', 'credit card', 'urgent', 'click here', 'limited time']
        
        score = 0
        for keyword in suspicious_keywords:
            if keyword.lower() in content.lower():
                score += 20
        
        if score >= 60:
            classification = "Fraudulent"
        elif score >= 30:
            classification = "Suspicious"
        else:
            classification = "Legitimate"
        
        return jsonify({
            "classification": classification,
            "risk_score": min(score, 100),
            "patterns_detected": [kw for kw in suspicious_keywords if kw.lower() in content.lower()]
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 400

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)
