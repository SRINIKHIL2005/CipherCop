from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app, origins="*")  # Allow all origins for testing

@app.route('/')
def home():
    return jsonify({"message": "CipherCop Backend - Test Version", "status": "active"})

@app.route('/classify/content', methods=['POST', 'OPTIONS'])
def classify_content():
    if request.method == 'OPTIONS':
        # Handle preflight request
        response = jsonify({'status': 'ok'})
        response.headers.add('Access-Control-Allow-Origin', '*')
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type')
        response.headers.add('Access-Control-Allow-Methods', 'POST')
        return response
    
    try:
        data = request.get_json()
        if not data or 'content' not in data:
            return jsonify({"error": "Content is required", "success": False}), 400
        
        content = data.get('content', '').lower()
        
        # Simple classification logic
        risk_score = 0
        patterns = []
        
        # Check for fraudulent keywords
        fraudulent_keywords = ['urgent', 'verify', 'suspended', 'click here', 'account locked']
        for keyword in fraudulent_keywords:
            if keyword in content:
                risk_score += 25
                patterns.append(f"Fraudulent keyword: {keyword}")
        
        # Determine classification
        if risk_score >= 70:
            classification = "Fraudulent"
        elif risk_score >= 30:
            classification = "Suspicious"
        else:
            classification = "Legitimate"
        
        response_data = {
            "success": True,
            "classification": classification,
            "risk_score": min(risk_score, 100),
            "confidence": 85.0,
            "patterns_detected": patterns[:3],
            "recommendation": f"Content classified as {classification}"
        }
        
        response = jsonify(response_data)
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response
        
    except Exception as e:
        error_response = jsonify({"error": str(e), "success": False})
        error_response.headers.add('Access-Control-Allow-Origin', '*')
        return error_response, 500

if __name__ == '__main__':
    print("🛡️ CipherCop Test Backend Starting...")
    print("✅ Basic Classification: READY")
    app.run(debug=True, host='127.0.0.1', port=5000)
